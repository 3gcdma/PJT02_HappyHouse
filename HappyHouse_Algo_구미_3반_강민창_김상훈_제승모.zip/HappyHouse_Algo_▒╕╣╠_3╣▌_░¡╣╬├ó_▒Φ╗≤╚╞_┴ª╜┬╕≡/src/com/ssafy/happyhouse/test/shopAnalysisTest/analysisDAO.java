package com.ssafy.happyhouse.test.shopAnalysisTest;

import java.util.List;

public interface analysisDAO {
	List<Shop> Search(String area);
}
